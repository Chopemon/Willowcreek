"""
NPC Entity Class - Type-safe NPC definition with autonomous behaviors
"""

from pydantic import BaseModel, Field, validator
from typing import Dict, List, Optional, Set
from enum import Enum
from datetime import datetime
import random


class Gender(str, Enum):
    """NPC Gender"""
    MALE = "male"
    FEMALE = "female"
    NON_BINARY = "non-binary"


class RelationshipType(str, Enum):
    """Relationship types"""
    STRANGER = "stranger"
    ACQUAINTANCE = "acquaintance"
    FRIEND = "friend"
    CLOSE_FRIEND = "close_friend"
    ROMANTIC = "romantic"
    FAMILY = "family"
    RIVAL = "rival"
    ENEMY = "enemy"


class PsychologicalState(BaseModel):
    """NPC psychological state"""
    drunk: float = Field(default=0.0, ge=0, le=10)
    lonely: float = Field(default=0.0, ge=0, le=10)
    frustrated: float = Field(default=0.0, ge=0, le=10)
    horny: float = Field(default=0.0, ge=0, le=10)
    angry: float = Field(default=0.0, ge=0, le=10)
    depressed: float = Field(default=0.0, ge=0, le=10)
    anxious: float = Field(default=0.0, ge=0, le=10)
    
    def decay(self, amount: float = 0.1):
        """Natural decay of extreme states"""
        for field in self.model_fields:
            current = getattr(self, field)
            setattr(self, field, max(0.0, current - amount))
    
    def is_desperate(self, threshold: float = 8.0) -> bool:
        """Check if any state is critically high"""
        return any(getattr(self, field) >= threshold 
                   for field in self.model_fields)


class Needs(BaseModel):
    """NPC basic needs"""
    hunger: float = Field(default=0.0, ge=0, le=10)
    social: float = Field(default=0.0, ge=0, le=10)
    sleep: float = Field(default=0.0, ge=0, le=10)
    hygiene: float = Field(default=0.0, ge=0, le=10)
    entertainment: float = Field(default=0.0, ge=0, le=10)
    
    def update(self, time_delta: float):
        """Update needs based on time passage"""
        self.hunger = min(10.0, self.hunger + time_delta * random.uniform(0.05, 0.15))
        self.social = min(10.0, self.social + time_delta * random.uniform(0.08, 0.12))
        self.sleep = min(10.0, self.sleep + time_delta * random.uniform(0.1, 0.2))
        self.hygiene = min(10.0, self.hygiene + time_delta * random.uniform(0.03, 0.07))
        self.entertainment = min(10.0, self.entertainment + time_delta * random.uniform(0.05, 0.1))
    
    def get_most_urgent(self) -> tuple[str, float]:
        """Get the most urgent need"""
        needs_dict = self.model_dump()
        most_urgent = max(needs_dict.items(), key=lambda x: x[1])
        return most_urgent


class Personality(BaseModel):
    """Big Five personality traits"""
    openness: float = Field(default=5.0, ge=0, le=10)
    conscientiousness: float = Field(default=5.0, ge=0, le=10)
    extroversion: float = Field(default=5.0, ge=0, le=10)
    agreeableness: float = Field(default=5.0, ge=0, le=10)
    neuroticism: float = Field(default=5.0, ge=0, le=10)
    
    @classmethod
    def generate_random(cls) -> 'Personality':
        """Generate random personality"""
        return cls(
            openness=random.gauss(5, 2),
            conscientiousness=random.gauss(5, 2),
            extroversion=random.gauss(5, 2),
            agreeableness=random.gauss(5, 2),
            neuroticism=random.gauss(5, 2)
        )


class NPC(BaseModel):
    """
    Non-Player Character - Autonomous agent in Willow Creek
    
    Type-safe, validated NPC with autonomous behaviors
    """
    
    # Identity
    full_name: str = Field(..., min_length=1)
    first_name: str = Field(default="")
    last_name: str = Field(default="")
    age: int = Field(..., ge=0, le=120)
    gender: Gender
    
    # Location & Occupation
    home_address: Optional[str] = None
    current_location: str = Field(default="home")
    occupation: Optional[str] = None
    
    # Birthday (for aging)
    birth_month: int = Field(default=1, ge=1, le=12)
    birth_day: int = Field(default=1, ge=1, le=31)
    
    # Attributes
    personality: Personality = Field(default_factory=Personality.generate_random)
    needs: Needs = Field(default_factory=Needs)
    psych_state: PsychologicalState = Field(default_factory=PsychologicalState)
    
    # Relationships (tracked externally but referenced here)
    relationship_ids: Set[str] = Field(default_factory=set)
    
    # State tracking
    current_goal: Optional[str] = None
    schedule: Dict[int, str] = Field(default_factory=dict)  # hour -> activity
    last_interaction_day: int = 0
    
    # Metadata
    created_at: datetime = Field(default_factory=datetime.now)
    
    class Config:
        validate_assignment = True
        use_enum_values = False
    
    @validator('first_name', 'last_name', always=True)
    def parse_name(cls, v, values):
        """Auto-parse first/last name from full_name"""
        if not v and 'full_name' in values:
            parts = values['full_name'].split(' ', 1)
            if len(parts) == 2:
                return parts[1] if cls.__name__ == 'last_name' else parts[0]
            return parts[0]
        return v
    
    def __str__(self) -> str:
        return f"{self.full_name} ({self.age}, {self.gender.value})"
    
    def __repr__(self) -> str:
        return f"NPC(name='{self.full_name}', age={self.age}, location='{self.current_location}')"
    
    # =========================================================================
    # AUTONOMOUS BEHAVIOR METHODS
    # =========================================================================
    
    def update_state(self, time_delta: float):
        """Update NPC state based on time passage"""
        # Update needs
        self.needs.update(time_delta)
        
        # Decay psychological states
        self.psych_state.decay(time_delta * 0.5)
    
    def get_behavior_weights(self) -> Dict[str, float]:
        """
        Calculate weights for different behaviors based on needs and state
        Returns dict of behavior -> probability weight
        """
        weights = {}
        
        # Basic needs drive behavior
        if self.needs.hunger > 7.0:
            weights['eat'] = self.needs.hunger * 2
        if self.needs.social > 7.0:
            weights['socialize'] = self.needs.social * 1.5
        if self.needs.sleep > 8.0:
            weights['sleep'] = self.needs.sleep * 3
        
        # Psychological states
        if self.psych_state.lonely > 6.0:
            weights['seek_company'] = self.psych_state.lonely
        if self.psych_state.horny > 7.0 and self.age >= 16:
            weights['seek_romance'] = self.psych_state.horny
        if self.psych_state.frustrated > 6.0:
            weights['vent_frustration'] = self.psych_state.frustrated
        
        # Personality influences
        if self.personality.extroversion > 7.0:
            weights['socialize'] = weights.get('socialize', 0) + 2.0
        if self.personality.conscientiousness > 7.0:
            weights['work'] = 3.0
        
        # Age-appropriate behaviors
        if self.age < 18:
            weights['attend_school'] = 10.0
            weights.pop('seek_romance', None)  # Remove for minors
        
        return weights
    
    def choose_action(self) -> str:
        """Choose next action based on behavior weights"""
        weights = self.get_behavior_weights()
        
        if not weights:
            return "idle"
        
        # Weighted random choice
        actions = list(weights.keys())
        probabilities = [weights[a] for a in actions]
        total = sum(probabilities)
        probabilities = [p / total for p in probabilities]
        
        return random.choices(actions, weights=probabilities)[0]
    
    def is_available_for_interaction(self) -> bool:
        """Check if NPC can interact (not sleeping, working, etc.)"""
        most_urgent = self.needs.get_most_urgent()
        if most_urgent[0] == 'sleep' and most_urgent[1] > 8.0:
            return False
        return True
    
    def can_have_romantic_interaction(self) -> bool:
        """Check if NPC can have romantic/sexual interaction"""
        if self.age < 16:
            return False
        if self.psych_state.horny < 5.0 and self.psych_state.lonely < 6.0:
            return False
        return True
    
    def to_dict(self) -> dict:
        """Convert to dictionary for export"""
        return self.model_dump()
    
    def to_js_format(self) -> dict:
        """Convert to JavaScript-compatible format for JanitorAI"""
        return {
            'fullName': self.full_name,
            'firstName': self.first_name,
            'lastName': self.last_name,
            'age': self.age,
            'gender': self.gender.value,
            'homeAddress': self.home_address,
            'currentLocation': self.current_location,
            'occupation': self.occupation,
            'birthMonth': self.birth_month,
            'birthDay': self.birth_day,
            'personality': {
                'openness': self.personality.openness,
                'conscientiousness': self.personality.conscientiousness,
                'extroversion': self.personality.extroversion,
                'agreeableness': self.personality.agreeableness,
                'neuroticism': self.personality.neuroticism
            },
            'needs': self.needs.model_dump(),
            'psychState': self.psych_state.model_dump()
        }


# =========================================================================
# FACTORY FUNCTIONS
# =========================================================================

def create_npc(
    full_name: str,
    age: int,
    gender: Gender,
    occupation: Optional[str] = None,
    home_address: Optional[str] = None
) -> NPC:
    """Factory function to create NPC with sensible defaults"""
    return NPC(
        full_name=full_name,
        age=age,
        gender=gender,
        occupation=occupation,
        home_address=home_address,
        personality=Personality.generate_random()
    )


def create_npc_from_js(js_data: dict) -> NPC:
    """Create NPC from JavaScript export data"""
    return NPC(
        full_name=js_data.get('fullName', js_data.get('name', 'Unknown')),
        age=js_data.get('age', 25),
        gender=Gender(js_data.get('gender', 'male').lower()),
        occupation=js_data.get('occupation'),
        home_address=js_data.get('homeAddress'),
        birth_month=js_data.get('birthMonth', random.randint(1, 12)),
        birth_day=js_data.get('birthDay', random.randint(1, 28)),
        current_location=js_data.get('currentLocation', 'home')
    )


if __name__ == "__main__":
    # Demo usage
    npc = create_npc(
        full_name="Maria Sturm",
        age=35,
        gender=Gender.FEMALE,
        occupation="Housewife",
        home_address="103 Oak St"
    )
    
    print(npc)
    print(f"Personality: {npc.personality}")
    print(f"Most urgent need: {npc.needs.get_most_urgent()}")
    
    # Simulate time passage
    npc.update_state(1.0)
    print(f"After 1 hour: {npc.needs.get_most_urgent()}")
    
    # Choose action
    action = npc.choose_action()
    print(f"Next action: {action}")
