"""
Time System - Efficient time progression and management
"""

from datetime import datetime, timedelta
from typing import Optional


class TimeSystem:
    """
    Manages simulation time with real-world sync capability
    """
    
    def __init__(self, start_time: Optional[datetime] = None):
        """
        Initialize time system
        
        Args:
            start_time: Starting datetime (default: Sept 1, 2025, 8:00 AM)
        """
        self.current_time = start_time or datetime(2025, 9, 1, 8, 0)
        self.start_time = self.current_time
        self.total_days = 1
        self.total_hours = 0
        self.total_minutes = 0
        
    @property
    def hour(self) -> int:
        return self.current_time.hour
    
    @property
    def minute(self) -> int:
        return self.current_time.minute
    
    @property
    def day_of_week(self) -> int:
        """Day of week (0=Monday, 6=Sunday)"""
        return self.current_time.weekday()
    
    @property
    def day_name(self) -> str:
        return self.current_time.strftime("%A")
    
    @property
    def season(self) -> str:
        """Current season"""
        month = self.current_time.month
        if month in [3, 4, 5]:
            return "Spring"
        elif month in [6, 7, 8]:
            return "Summer"
        elif month in [9, 10, 11]:
            return "Autumn"
        else:
            return "Winter"
    
    @property
    def is_weekend(self) -> bool:
        return self.day_of_week >= 5
    
    @property
    def is_school_hours(self) -> bool:
        """Check if it's school hours (8am-3pm, Mon-Fri)"""
        return (not self.is_weekend) and (8 <= self.hour < 15)
    
    @property
    def is_business_hours(self) -> bool:
        """Check if it's business hours (9am-5pm, Mon-Fri)"""
        return (not self.is_weekend) and (9 <= self.hour < 17)
    
    @property
    def time_of_day(self) -> str:
        """Get time of day category"""
        hour = self.hour
        if 5 <= hour < 12:
            return "morning"
        elif 12 <= hour < 17:
            return "afternoon"
        elif 17 <= hour < 21:
            return "evening"
        else:
            return "night"
    
    def advance(self, hours: float = 1.0):
        """
        Advance time by specified hours
        
        Args:
            hours: Hours to advance (can be fractional)
        """
        delta = timedelta(hours=hours)
        old_day = self.current_time.day
        
        self.current_time += delta
        self.total_minutes += int(hours * 60)
        self.total_hours += hours
        
        # Check if day changed
        if self.current_time.day != old_day:
            self.total_days += 1
    
    def get_date_string(self) -> str:
        """Get formatted date string"""
        return self.current_time.strftime("%B %d, %Y")
    
    def get_time_string(self) -> str:
        """Get formatted time string"""
        return self.current_time.strftime("%I:%M %p")
    
    def get_datetime_string(self) -> str:
        """Get full datetime string"""
        return f"{self.day_name}, {self.get_date_string()} at {self.get_time_string()}"
    
    def __str__(self) -> str:
        return f"Day {self.total_days} - {self.get_datetime_string()}"
    
    def __repr__(self) -> str:
        return f"TimeSystem(day={self.total_days}, time={self.get_time_string()})"
