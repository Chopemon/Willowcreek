"""World State Management"""
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core.time_system import TimeSystem

class WorldState:
    def __init__(self):
        self.town_name = "Willow Creek"
        self.population = 68
        self.weather = "Clear and mild"
    
    def update(self, time: 'TimeSystem'):
        """Update world state"""
        pass
