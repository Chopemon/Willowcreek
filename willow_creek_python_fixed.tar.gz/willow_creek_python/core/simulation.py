"""
Willow Creek 2025 - Main Simulation Engine

High-performance simulation orchestrator with autonomous NPCs
"""

from typing import List, Dict, Optional
from datetime import datetime, timedelta
import random
import json
from pathlib import Path

from entities.npc import NPC, create_npc, Gender
from systems.relationships import RelationshipManager
from systems.needs import NeedsSystem
from systems.autonomous import AutonomousSystem
from core.time_system import TimeSystem
from core.world_state import WorldState


class WillowCreekSimulation:
    """
    Main simulation engine for Willow Creek
    
    Orchestrates all NPCs, systems, and world state
    """
    
    def __init__(
        self,
        num_npcs: int = 40,
        start_date: Optional[datetime] = None,
        load_from_file: Optional[str] = None
    ):
        """
        Initialize simulation
        
        Args:
            num_npcs: Number of NPCs to create
            start_date: Starting date (default: Sept 1, 2025)
            load_from_file: Path to saved simulation state
        """
        print("=== WILLOW CREEK 2025 - PYTHON SIMULATION ===\n")
        
        # Initialize core systems
        self.time = TimeSystem(start_date or datetime(2025, 9, 1, 8, 0))
        self.world = WorldState()
        
        # Initialize NPCs
        self.npcs: List[NPC] = []
        self.npc_dict: Dict[str, NPC] = {}  # Fast lookup by name
        
        # Initialize subsystems
        self.relationships = RelationshipManager()
        self.needs_system = NeedsSystem()
        self.autonomous_system = AutonomousSystem(self)
        
        # Simulation state
        self.current_step = 0
        self.events_log = []
        self.statistics = {
            'total_interactions': 0,
            'affairs': 0,
            'hookups': 0,
            'fights': 0,
            'birthdays': 0
        }
        
        # Load or create NPCs
        if load_from_file:
            self.load_state(load_from_file)
        else:
            self._create_npcs(num_npcs)
            self._setup_initial_relationships()
        
        print(f"✓ Simulation initialized with {len(self.npcs)} NPCs")
        print(f"✓ Start date: {self.time.get_date_string()}\n")
    
    def _create_npcs(self, num_npcs: int):
        """Create initial NPC population"""
        print(f"Creating {num_npcs} NPCs...")
        
        # Try to load from imported NPCs first
        imported_file = Path("imported_npcs.json")
        if imported_file.exists():
            print("✓ Found imported_npcs.json - loading your NPCs!")
            self._load_npcs_from_json(imported_file)
            if len(self.npcs) >= num_npcs:
                print(f"✓ Loaded {len(self.npcs)} NPCs from file")
                return
        
        # Create some named NPCs from your JS files
        named_npcs = [
            ("Malcolm Newt", 25, Gender.MALE, "Newcomer", "105 Oak St"),
            ("Maria Sturm", 35, Gender.FEMALE, "Housewife", "103 Oak St"),
            ("John Sturm", 42, Gender.MALE, "Truck Driver", "103 Oak St"),
            ("Alex Sturm", 18, Gender.MALE, "Student", "103 Oak St"),
            ("Elena Sturm", 15, Gender.FEMALE, "Student", "103 Oak St"),
            ("Scarlet Carter", 38, Gender.FEMALE, "Teacher", "202 Maple Ave"),
            ("Daniel Carter", 40, Gender.MALE, "Engineer", "202 Maple Ave"),
            ("Tony Carter", 17, Gender.MALE, "Student", "202 Maple Ave"),
            ("Lianna Carter", 14, Gender.FEMALE, "Student", "202 Maple Ave"),
            ("Isabella Ruiz", 32, Gender.FEMALE, "Yoga Instructor", "301 Pine Way"),
            ("Lucas Ruiz", 10, Gender.MALE, "Student", "301 Pine Way"),
        ]
        
        # Create named NPCs
        for name, age, gender, occ, addr in named_npcs[:num_npcs]:
            npc = create_npc(name, age, gender, occ, addr)
            self.npcs.append(npc)
            self.npc_dict[name] = npc
        
        # Fill remaining with generated NPCs if needed
        if len(self.npcs) < num_npcs:
            remaining = num_npcs - len(self.npcs)
            for i in range(remaining):
                npc = self._generate_random_npc(i)
                self.npcs.append(npc)
                self.npc_dict[npc.full_name] = npc
        
        print(f"✓ Created {len(self.npcs)} NPCs")
    
    def _generate_random_npc(self, index: int) -> NPC:
        """Generate a random NPC"""
        first_names_m = ["James", "Michael", "David", "Robert", "William"]
        first_names_f = ["Emma", "Olivia", "Sophia", "Isabella", "Ava"]
        last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones"]
        
        gender = random.choice([Gender.MALE, Gender.FEMALE])
        first_name = random.choice(first_names_m if gender == Gender.MALE else first_names_f)
        last_name = random.choice(last_names)
        
        return create_npc(
            full_name=f"{first_name} {last_name} {index}",
            age=random.randint(18, 65),
            gender=gender,
            occupation=random.choice(["Teacher", "Clerk", "Mechanic", "Nurse", "Unemployed"]),
            home_address=f"{random.randint(100, 999)} Main St"
        )
    
    def _load_npcs_from_json(self, filepath: Path):
        """Load NPCs from JSON file"""
        import json
        
        data = json.loads(filepath.read_text(encoding='utf-8'))
        
        for npc_data in data:
            try:
                npc = NPC(**npc_data)
                self.npcs.append(npc)
                self.npc_dict[npc.full_name] = npc
            except Exception as e:
                print(f"⚠️  Skipping NPC: {e}")
                continue
    
    def _setup_initial_relationships(self):
        """Set up initial family and social relationships"""
        print("Setting up initial relationships...")
        
        # Sturm family
        if "Maria Sturm" in self.npc_dict and "John Sturm" in self.npc_dict:
            self.relationships.create_relationship(
                "Maria Sturm", "John Sturm",
                rel_type="romantic", level=6, attraction=60
            )
        
        if "Maria Sturm" in self.npc_dict and "Alex Sturm" in self.npc_dict:
            self.relationships.create_relationship(
                "Maria Sturm", "Alex Sturm",
                rel_type="family", level=7
            )
        
        # More families can be added here...
        
        print(f"✓ Created {len(self.relationships.relationships)} initial relationships")
    
    def step(self, time_delta: float = 1.0):
        """
        Advance simulation by one time step
        
        Args:
            time_delta: Time in hours to advance
        """
        self.current_step += 1
        
        # Advance time
        self.time.advance(time_delta)
        
        # Update all NPCs
        for npc in self.npcs:
            npc.update_state(time_delta)
        
        # Run subsystems
        self.needs_system.process_needs(self.npcs, time_delta)
        self.autonomous_system.process_autonomous_behaviors(time_delta)
        
        # Check for special events
        self._check_birthdays()
        
        # Update world state
        self.world.update(self.time)
    
    def _check_birthdays(self):
        """Check if any NPCs have birthdays today"""
        current_month = self.time.current_time.month
        current_day = self.time.current_time.day
        
        for npc in self.npcs:
            if npc.birth_month == current_month and npc.birth_day == current_day:
                npc.age += 1
                self.log_event('birthday', npc.full_name, {'new_age': npc.age})
                self.statistics['birthdays'] += 1
                print(f"🎂 BIRTHDAY: {npc.full_name} is now {npc.age}!")
    
    def run(self, num_steps: int = 100, steps_per_day: int = 24):
        """
        Run simulation for specified number of steps
        
        Args:
            num_steps: Number of steps to run
            steps_per_day: Steps per simulated day (default: 24 = hourly)
        """
        print(f"\n=== RUNNING SIMULATION FOR {num_steps} STEPS ===\n")
        
        time_delta = 24.0 / steps_per_day  # Hours per step
        
        for i in range(num_steps):
            self.step(time_delta)
            
            # Progress report every 10% completion
            if (i + 1) % (num_steps // 10) == 0:
                progress = ((i + 1) / num_steps) * 100
                print(f"Progress: {progress:.0f}% - Day {self.time.total_days}")
                print(f"  Stats: {self.statistics}")
        
        print(f"\n✓ Simulation complete!")
        print(f"  Total days: {self.time.total_days}")
        print(f"  Final statistics: {self.statistics}")
    
    def log_event(self, event_type: str, npc_name: str, details: dict):
        """Log a simulation event"""
        self.events_log.append({
            'step': self.current_step,
            'day': self.time.total_days,
            'time': self.time.get_time_string(),
            'type': event_type,
            'npc': npc_name,
            **details
        })
    
    def get_summary(self) -> str:
        """Get current simulation summary"""
        return (f"Day {self.time.total_days} - {self.time.get_time_string()} - "
                f"{len(self.npcs)} NPCs - {len(self.relationships.relationships)} relationships")
    
    def get_npc(self, name: str) -> Optional[NPC]:
        """Get NPC by name"""
        return self.npc_dict.get(name)
    
    def get_npcs_at_location(self, location: str) -> List[NPC]:
        """Get all NPCs at a specific location"""
        return [npc for npc in self.npcs if npc.current_location == location]
    
    def save_state(self, filename: str):
        """Save simulation state to file"""
        print(f"Saving simulation state to {filename}...")
        
        state = {
            'metadata': {
                'saved_at': datetime.now().isoformat(),
                'current_step': self.current_step,
                'version': '1.0'
            },
            'time': {
                'current_time': self.time.current_time.isoformat(),
                'total_days': self.time.total_days,
                'season': self.time.season
            },
            'npcs': [npc.to_dict() for npc in self.npcs],
            'relationships': self.relationships.export(),
            'statistics': self.statistics,
            'events_log': self.events_log[-100:]  # Last 100 events
        }
        
        Path(filename).write_text(json.dumps(state, indent=2))
        print(f"✓ State saved successfully")
    
    def load_state(self, filename: str):
        """Load simulation state from file"""
        print(f"Loading simulation state from {filename}...")
        
        state = json.loads(Path(filename).read_text())
        
        # Restore time
        self.time.current_time = datetime.fromisoformat(state['time']['current_time'])
        self.time.total_days = state['time']['total_days']
        
        # Restore NPCs
        # This would need proper deserialization logic
        
        print(f"✓ State loaded successfully")
    
    def export_to_janitor_ai(self, output_file: str):
        """Export current state to JavaScript for JanitorAI"""
        from exporters.janitor_ai import export_to_js
        
        export_to_js(self, output_file)
        print(f"✓ Exported to {output_file}")
    
    def get_statistics(self) -> Dict:
        """Get detailed simulation statistics"""
        return {
            **self.statistics,
            'current_step': self.current_step,
            'total_days': self.time.total_days,
            'num_npcs': len(self.npcs),
            'num_relationships': len(self.relationships.relationships),
            'avg_relationship_level': self.relationships.get_average_relationship_level(),
            'most_connected': self.relationships.get_most_connected_npc()
        }


if __name__ == "__main__":
    # Demo run
    sim = WillowCreekSimulation(num_npcs=12)
    sim.run(num_steps=50, steps_per_day=24)
    
    print("\n=== FINAL STATISTICS ===")
    stats = sim.get_statistics()
    for key, value in stats.items():
        print(f"  {key}: {value}")
