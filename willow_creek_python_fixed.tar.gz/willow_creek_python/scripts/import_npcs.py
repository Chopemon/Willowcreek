#!/usr/bin/env python3
"""
Import NPCs from JavaScript files

This script reads your existing NPC .js files and creates Python NPC objects
"""

import sys
import re
import json
from pathlib import Path
from typing import List, Dict

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from entities.npc import NPC, Gender, create_npc


def parse_js_npc_file(filepath: Path) -> Dict:
    """
    Parse a JavaScript NPC file and extract NPC data
    
    Args:
        filepath: Path to .js file
    
    Returns:
        Dictionary with NPC data
    """
    content = filepath.read_text(encoding='utf-8')
    
    npc_data = {
        'fullName': None,
        'age': None,
        'gender': None,
        'occupation': None,
        'homeAddress': None
    }
    
    # Extract full name
    name_match = re.search(r'fullName[:\s]+"([^"]+)"', content)
    if name_match:
        npc_data['fullName'] = name_match.group(1)
    
    # Extract age
    age_match = re.search(r'\bage[:\s]+(\d+)', content)
    if age_match:
        npc_data['age'] = int(age_match.group(1))
    
    # Extract gender
    gender_match = re.search(r'gender[:\s]+"([^"]+)"', content)
    if gender_match:
        npc_data['gender'] = gender_match.group(1).lower()
    
    # Extract occupation
    occ_match = re.search(r'occupation[:\s]+"([^"]+)"', content)
    if occ_match:
        npc_data['occupation'] = occ_match.group(1)
    
    # Extract home address
    addr_match = re.search(r'homeAddress[:\s]+"([^"]+)"', content)
    if addr_match:
        npc_data['homeAddress'] = addr_match.group(1)
    
    return npc_data


def import_npcs_from_directory(npc_dir: str) -> List[NPC]:
    """
    Import all NPCs from a directory of .js files
    
    Args:
        npc_dir: Path to directory containing NPC .js files
    
    Returns:
        List of NPC objects
    """
    npc_path = Path(npc_dir)
    
    if not npc_path.exists():
        print(f"❌ Directory not found: {npc_dir}")
        print(f"   Please provide the path to your NPC .js files")
        return []
    
    js_files = list(npc_path.glob("*.js"))
    print(f"\n📁 Found {len(js_files)} .js files in {npc_dir}")
    
    npcs = []
    failed = []
    
    for js_file in js_files:
        try:
            npc_data = parse_js_npc_file(js_file)
            
            # Validate required fields
            if not npc_data['fullName'] or not npc_data['age'] or not npc_data['gender']:
                print(f"⚠️  Skipping {js_file.name}: Missing required data")
                failed.append(js_file.name)
                continue
            
            # Create NPC
            npc = create_npc(
                full_name=npc_data['fullName'],
                age=npc_data['age'],
                gender=Gender(npc_data['gender']),
                occupation=npc_data.get('occupation'),
                home_address=npc_data.get('homeAddress')
            )
            
            npcs.append(npc)
            print(f"✓ Imported: {npc.full_name} ({npc.age}, {npc.gender.value})")
            
        except Exception as e:
            print(f"❌ Failed to import {js_file.name}: {e}")
            failed.append(js_file.name)
    
    print(f"\n✓ Successfully imported {len(npcs)} NPCs")
    if failed:
        print(f"⚠️  Failed to import {len(failed)} files:")
        for f in failed:
            print(f"   - {f}")
    
    return npcs


def save_npcs_to_json(npcs: List[NPC], output_file: str):
    """Save NPCs to JSON file for easy loading"""
    npc_data = [npc.to_dict() for npc in npcs]
    
    Path(output_file).write_text(
        json.dumps(npc_data, indent=2, default=str),
        encoding='utf-8'
    )
    
    print(f"\n✓ Saved {len(npcs)} NPCs to {output_file}")


if __name__ == "__main__":
    print("=" * 60)
    print("WILLOW CREEK - NPC IMPORTER")
    print("=" * 60)
    
    # You can specify your NPC directory here
    # Option 1: Command line argument
    if len(sys.argv) > 1:
        npc_directory = sys.argv[1]
    else:
        # Option 2: Hardcoded path (change this to your NPC folder)
        print("\nℹ️  Usage: python import_npcs.py <path_to_npc_folder>")
        print("   Example: python import_npcs.py ../original_project/npc/")
        
        # Try common locations
        possible_paths = [
            "../npc",
            "../../npc",
            "../original_project/npc",
            "G:/Willowcreek/npc"
        ]
        
        npc_directory = None
        for path in possible_paths:
            if Path(path).exists():
                npc_directory = path
                print(f"\n✓ Found NPC directory: {npc_directory}")
                break
        
        if not npc_directory:
            print("\n❌ Could not find NPC directory")
            print("   Please run: python import_npcs.py <your_npc_folder_path>")
            sys.exit(1)
    
    # Import NPCs
    npcs = import_npcs_from_directory(npc_directory)
    
    if npcs:
        # Save to JSON for easy loading later
        save_npcs_to_json(npcs, "imported_npcs.json")
        
        print("\n" + "=" * 60)
        print("IMPORT COMPLETE!")
        print("=" * 60)
        print(f"\n✓ {len(npcs)} NPCs imported successfully")
        print(f"✓ Saved to: imported_npcs.json")
        print("\nNext steps:")
        print("  1. Edit demo.py to load from imported_npcs.json")
        print("  2. Run: python demo.py")
        print("  3. Enjoy your full simulation with 40+ NPCs!")
