#!/usr/bin/env python3
"""
Willow Creek 2025 - Main Demo Script

Run this to see the Python simulation in action
"""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.simulation import WillowCreekSimulation


def main():
    """Run demo simulation"""
    print("=" * 60)
    print("WILLOW CREEK 2025 - PYTHON SIMULATION DEMO")
    print("=" * 60)
    print()
    
    # Create simulation with 12 NPCs
    sim = WillowCreekSimulation(num_npcs=12)
    
    print("\n" + "=" * 60)
    print("RUNNING SIMULATION")
    print("=" * 60)
    print()
    
    # Run for 100 steps (about 4 days at hourly resolution)
    sim.run(num_steps=100, steps_per_day=24)
    
    print("\n" + "=" * 60)
    print("FINAL STATISTICS")
    print("=" * 60)
    print()
    
    stats = sim.get_statistics()
    for key, value in stats.items():
        print(f"  {key:25s}: {value}")
    
    print("\n" + "=" * 60)
    print("EXPORTING TO JANITORAI FORMAT")
    print("=" * 60)
    print()
    
    # Export to JavaScript
    output_file = "willow_creek_export.js"
    sim.export_to_janitor_ai(output_file)
    
    print("\n" + "=" * 60)
    print("DEMO COMPLETE!")
    print("=" * 60)
    print()
    print(f"✓ Simulation ran for {sim.time.total_days} days")
    print(f"✓ Final time: {sim.time.get_datetime_string()}")
    print(f"✓ JavaScript export: {output_file}")
    print()
    print("Next steps:")
    print("  1. Check the exported JavaScript file")
    print("  2. Load it in your JanitorAI lorebook")
    print("  3. Enjoy your pre-simulated world state!")
    print()


if __name__ == "__main__":
    main()
