"""Needs System - Process NPC needs"""
from typing import List
from entities.npc import NPC

class NeedsSystem:
    def process_needs(self, npcs: List[NPC], time_delta: float):
        """Process needs for all NPCs"""
        pass  # Already handled in NPC.update_state()
