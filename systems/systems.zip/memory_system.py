# systems/memory_system.py
"""
Memory System v2.0
Purpose: NPCs remember events, relationships, and information realistically
"""

from typing import Dict, List, Optional, Set, TYPE_CHECKING
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import random

if TYPE_CHECKING:
    from entities.npc import NPC


class MemoryType(str, Enum):
    PERSONAL_EVENT = "personal_event"
    WITNESSED = "witnessed"
    GOSSIP = "gossip"
    RELATIONSHIP = "relationship"
    TRAUMA = "trauma"
    ACHIEVEMENT = "achievement"
    SECRET = "secret"
    LOCATION = "location"


class MemoryImportance(str, Enum):
    TRIVIAL = "trivial"          # Forgotten quickly
    NORMAL = "normal"             # Standard memory
    IMPORTANT = "important"       # Remembered long-term
    SIGNIFICANT = "significant"   # Life-changing events
    TRAUMATIC = "traumatic"       # Never forgotten


@dataclass
class Memory:
    """A single memory"""
    content: str
    memory_type: MemoryType
    importance: MemoryImportance
    day_created: int
    emotions_felt: List[str] = field(default_factory=list)
    people_involved: List[str] = field(default_factory=list)
    location: Optional[str] = None
    
    # Memory strength (0-100, decays over time unless important)
    strength: float = 100.0
    
    # Times recalled (reinforces memory)
    recall_count: int = 0
    last_recalled: int = 0
    
    def decay(self, days_since_creation: int, decay_rate: float = 0.5):
        """Memories fade over time unless important"""
        if self.importance == MemoryImportance.TRAUMATIC:
            return  # Traumatic memories don't decay
        
        if self.importance == MemoryImportance.SIGNIFICANT:
            decay_rate *= 0.3  # Significant memories decay slowly
        
        if self.importance == MemoryImportance.IMPORTANT:
            decay_rate *= 0.6
        
        # Recalled memories are stronger
        strength_bonus = min(20, self.recall_count * 2)
        
        self.strength = max(0, self.strength - (decay_rate * days_since_creation) + strength_bonus)
    
    def recall(self, current_day: int):
        """Recalling a memory reinforces it"""
        self.recall_count += 1
        self.last_recalled = current_day
        self.strength = min(100, self.strength + 5)


@dataclass
class MemoryCluster:
    """Group of related memories (e.g., all memories about a person)"""
    cluster_name: str
    memories: List[Memory] = field(default_factory=list)
    
    def add_memory(self, memory: Memory):
        """Add memory to cluster"""
        self.memories.append(memory)
    
    def get_strongest_memories(self, count: int = 5) -> List[Memory]:
        """Get the strongest memories from this cluster"""
        return sorted(self.memories, key=lambda m: m.strength, reverse=True)[:count]
    
    def forget_weak_memories(self, threshold: float = 10.0):
        """Remove memories below strength threshold"""
        self.memories = [m for m in self.memories if m.strength >= threshold]


class MemorySystem:
    """
    Advanced memory system for NPCs
    Manages realistic memory formation, recall, and forgetting
    """
    
    def __init__(self):
        # npc_name -> List[Memory]
        self.memories: Dict[str, List[Memory]] = {}
        
        # npc_name -> Dict[cluster_name, MemoryCluster]
        self.memory_clusters: Dict[str, Dict[str, MemoryCluster]] = {}
        
        # npc_name -> Set[secret_str]
        self.secrets: Dict[str, Set[str]] = {}
        
        self.initialized = False
    
    def initialize_npc_memory(self, npc_name: str):
        """Initialize memory storage for an NPC"""
        if npc_name not in self.memories:
            self.memories[npc_name] = []
            self.memory_clusters[npc_name] = {}
            self.secrets[npc_name] = set()
    
    def add_memory(
        self,
        npc_name: str,
        content: str,
        memory_type: MemoryType,
        importance: MemoryImportance,
        current_day: int,
        emotions_felt: Optional[List[str]] = None,
        people_involved: Optional[List[str]] = None,
        location: Optional[str] = None
    ) -> Memory:
        """Create and store a new memory"""
        self.initialize_npc_memory(npc_name)
        
        memory = Memory(
            content=content,
            memory_type=memory_type,
            importance=importance,
            day_created=current_day,
            emotions_felt=emotions_felt or [],
            people_involved=people_involved or [],
            location=location
        )
        
        self.memories[npc_name].append(memory)
        
        # Add to relevant clusters
        if people_involved:
            for person in people_involved:
                self._add_to_cluster(npc_name, f"about_{person}", memory)
        
        if location:
            self._add_to_cluster(npc_name, f"at_{location}", memory)
        
        print(f"📝 {npc_name} forms memory: {content[:50]}... (importance: {importance.value})")
        
        return memory
    
    def _add_to_cluster(self, npc_name: str, cluster_name: str, memory: Memory):
        """Add memory to a cluster"""
        if cluster_name not in self.memory_clusters[npc_name]:
            self.memory_clusters[npc_name][cluster_name] = MemoryCluster(cluster_name=cluster_name)
        
        self.memory_clusters[npc_name][cluster_name].add_memory(memory)
    
    def add_secret(self, npc_name: str, secret: str):
        """Add a secret that the NPC keeps"""
        self.initialize_npc_memory(npc_name)
        self.secrets[npc_name].add(secret)
    
    def knows_secret(self, npc_name: str, secret: str) -> bool:
        """Check if NPC knows a secret"""
        return secret in self.secrets.get(npc_name, set())
    
    def share_secret(self, from_npc: str, to_npc: str, secret: str, current_day: int):
        """One NPC shares a secret with another"""
        if not self.knows_secret(from_npc, secret):
            return False
        
        self.add_secret(to_npc, secret)
        
        # Both remember this sharing event
        self.add_memory(
            npc_name=from_npc,
            content=f"Told {to_npc} about: {secret}",
            memory_type=MemoryType.RELATIONSHIP,
            importance=MemoryImportance.IMPORTANT,
            current_day=current_day,
            people_involved=[to_npc]
        )
        
        self.add_memory(
            npc_name=to_npc,
            content=f"{from_npc} told me: {secret}",
            memory_type=MemoryType.SECRET,
            importance=MemoryImportance.IMPORTANT,
            current_day=current_day,
            people_involved=[from_npc]
        )
        
        print(f"🤫 {from_npc} shared secret with {to_npc}")
        
        return True
    
    def recall_memories_about(
        self,
        npc_name: str,
        about: str,
        current_day: int,
        limit: int = 5
    ) -> List[Memory]:
        """Recall memories about a person or topic"""
        cluster_name = f"about_{about}"
        
        if npc_name not in self.memory_clusters:
            return []
        
        if cluster_name not in self.memory_clusters[npc_name]:
            return []
        
        cluster = self.memory_clusters[npc_name][cluster_name]
        memories = cluster.get_strongest_memories(limit)
        
        # Recall reinforces memories
        for memory in memories:
            memory.recall(current_day)
        
        return memories
    
    def recall_memories_at(
        self,
        npc_name: str,
        location: str,
        current_day: int,
        limit: int = 5
    ) -> List[Memory]:
        """Recall memories at a location"""
        cluster_name = f"at_{location}"
        
        if npc_name not in self.memory_clusters:
            return []
        
        if cluster_name not in self.memory_clusters[npc_name]:
            return []
        
        cluster = self.memory_clusters[npc_name][cluster_name]
        memories = cluster.get_strongest_memories(limit)
        
        for memory in memories:
            memory.recall(current_day)
        
        return memories
    
    def get_traumatic_memories(self, npc_name: str) -> List[Memory]:
        """Get all traumatic memories (never forgotten)"""
        if npc_name not in self.memories:
            return []
        
        return [
            m for m in self.memories[npc_name]
            if m.importance == MemoryImportance.TRAUMATIC
        ]
    
    def decay_memories(self, npc_name: str, current_day: int):
        """Process memory decay for an NPC"""
        if npc_name not in self.memories:
            return
        
        for memory in self.memories[npc_name]:
            days_since = current_day - memory.day_created
            memory.decay(days_since)
        
        # Remove forgotten memories (strength < 10)
        self.memories[npc_name] = [
            m for m in self.memories[npc_name]
            if m.strength >= 10
        ]
        
        # Clean up clusters
        for cluster in self.memory_clusters[npc_name].values():
            cluster.forget_weak_memories(threshold=10.0)
    
    def decay_all_memories(self, current_day: int):
        """Process memory decay for all NPCs"""
        for npc_name in list(self.memories.keys()):
            self.decay_memories(npc_name, current_day)
    
    def get_memory_summary(self, npc_name: str) -> Dict:
        """Get summary of NPC's memories"""
        if npc_name not in self.memories:
            return {}
        
        memories = self.memories[npc_name]
        
        return {
            'total_memories': len(memories),
            'secrets_known': len(self.secrets.get(npc_name, set())),
            'traumatic_memories': len([m for m in memories if m.importance == MemoryImportance.TRAUMATIC]),
            'important_memories': len([m for m in memories if m.importance in [MemoryImportance.IMPORTANT, MemoryImportance.SIGNIFICANT]]),
            'average_strength': sum(m.strength for m in memories) / len(memories) if memories else 0,
            'clusters': len(self.memory_clusters.get(npc_name, {}))
        }
    
    def get_statistics(self) -> Dict:
        """Get system statistics"""
        total_memories = sum(len(memories) for memories in self.memories.values())
        total_secrets = sum(len(secrets) for secrets in self.secrets.values())
        
        return {
            'npcs_with_memories': len(self.memories),
            'total_memories': total_memories,
            'total_secrets': total_secrets,
            'total_clusters': sum(len(clusters) for clusters in self.memory_clusters.values())
        }
    
    def export(self) -> Dict:
        """Export memory data"""
        return {
            'memories': {
                npc: [
                    {
                        'content': m.content,
                        'type': m.memory_type.value,
                        'importance': m.importance.value,
                        'day_created': m.day_created,
                        'strength': m.strength,
                        'people_involved': m.people_involved,
                        'location': m.location
                    }
                    for m in memories
                ]
                for npc, memories in self.memories.items()
            },
            'secrets': {
                npc: list(secrets)
                for npc, secrets in self.secrets.items()
            }
        }