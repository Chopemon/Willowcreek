# systems/goals_system.py
"""
Goals & Motivations System v1.0
Purpose: NPCs pursue goals proactively, creating emergent narratives
"""

from typing import Dict, List, Optional, TYPE_CHECKING
from dataclasses import dataclass, field
from enum import Enum
import random

if TYPE_CHECKING:
    from entities.npc import NPC
    from core.time_system import TimeSystem


class GoalType(str, Enum):
    ACADEMIC = "academic"
    SOCIAL = "social"
    REBELLION = "rebellion"
    CAREER = "career"
    FINANCIAL = "financial"
    RELATIONSHIP = "relationship"
    ESCAPE = "escape"
    SURVIVAL = "survival"
    INDEPENDENCE = "independence"
    HIDDEN = "hidden"
    SATISFACTION = "satisfaction"
    GUILT = "guilt"
    INTERNAL_CONFLICT = "internal_conflict"
    SECRECY = "secrecy"
    PHYSICAL_NEED = "physical_need"


@dataclass
class Goal:
    """Represents an NPC goal"""
    goal: str
    type: GoalType
    priority: int  # 1-10, higher is more important
    progress: float = 0.0  # 0-100
    difficulty: int = 50  # 0-100
    obstacles: List[str] = field(default_factory=list)
    days_active: int = 0
    last_attempt_day: int = 0
    duration: Optional[int] = None  # Expected days to complete
    
    # Status flags
    failing: bool = False
    succeeding: bool = False
    completed: bool = False
    abandoned: bool = False
    
    # Metadata
    method: Optional[str] = None
    shame_level: int = 0  # 0-10 for goals with emotional weight
    completion_reward: Optional[str] = None
    failure_consequence: Optional[str] = None
    
    def update_progress(self, amount: float):
        """Update goal progress"""
        self.progress = max(0, min(100, self.progress + amount))
        
        if self.progress >= 100:
            self.completed = True
            self.succeeding = True
        elif self.progress < 20:
            self.failing = True
            self.succeeding = False
        else:
            self.succeeding = self.progress > 50
            self.failing = False


@dataclass
class Achievement:
    """Track completed goals"""
    npc_name: str
    goal: str
    completed_day: int
    impact: str


@dataclass
class Failure:
    """Track failed goals"""
    npc_name: str
    goal: str
    failed_day: int
    consequence: str


class GoalsSystem:
    """
    Manages NPC goals and motivations
    Creates emergent narratives through goal pursuit
    """
    
    def __init__(self):
        self.goals: Dict[str, Dict[str, List[Goal]]] = {}
        self.achievements: List[Achievement] = []
        self.failures: List[Failure] = []
        self.initialized = False
        
    def initialize_npc_goals(self, npc: 'NPC', current_day: int):
        """Initialize goals for a specific NPC based on their profile"""
        if npc.full_name in self.goals:
            return
            
        self.goals[npc.full_name] = {
            'long_term': [],
            'short_term': [],
            'daily': []
        }
        
        # Add character-specific goals based on occupation/age/personality
        if npc.age < 18:
            self._add_student_goals(npc, current_day)
        elif npc.age >= 18:
            self._add_adult_goals(npc, current_day)
            
    def _add_student_goals(self, npc: 'NPC', current_day: int):
        """Add goals typical for students"""
        goals = self.goals[npc.full_name]
        
        # Academic goals
        goals['long_term'].append(Goal(
            goal="Maintain good grades",
            type=GoalType.ACADEMIC,
            priority=6,
            difficulty=50,
            duration=365,
            days_active=0
        ))
        
        # Social goals
        goals['long_term'].append(Goal(
            goal="Improve social status",
            type=GoalType.SOCIAL,
            priority=7,
            difficulty=70,
            duration=180,
            days_active=0
        ))
        
        # Daily goals
        goals['daily'].append(Goal(
            goal="Attend school",
            type=GoalType.ACADEMIC,
            priority=8,
            difficulty=10,
            duration=1
        ))
        
    def _add_adult_goals(self, npc: 'NPC', current_day: int):
        """Add goals typical for adults"""
        goals = self.goals[npc.full_name]
        
        # Career goals
        if npc.occupation:
            goals['long_term'].append(Goal(
                goal=f"Excel in {npc.occupation}",
                type=GoalType.CAREER,
                priority=7,
                difficulty=60,
                duration=365,
                days_active=0
            ))
        
        # Financial goals
        goals['long_term'].append(Goal(
            goal="Achieve financial stability",
            type=GoalType.FINANCIAL,
            priority=8,
            difficulty=70,
            duration=180,
            days_active=0
        ))
        
    def add_custom_goal(self, npc_name: str, goal: Goal, category: str = 'long_term'):
        """Add a custom goal for an NPC"""
        if npc_name not in self.goals:
            self.goals[npc_name] = {
                'long_term': [],
                'short_term': [],
                'daily': []
            }
        
        self.goals[npc_name][category].append(goal)
        
    def update_goals(self, npc_name: str, current_day: int, time_delta: float):
        """Update all goals for an NPC"""
        if npc_name not in self.goals:
            return
            
        for category in ['long_term', 'short_term', 'daily']:
            for goal in self.goals[npc_name][category]:
                goal.days_active += 1 if time_delta >= 24 else 0
                
                # Check for goal completion or failure
                if goal.completed:
                    self._record_achievement(npc_name, goal, current_day)
                elif goal.abandoned or (goal.duration and goal.days_active > goal.duration * 1.5):
                    self._record_failure(npc_name, goal, current_day)
                    
    def get_active_goals(self, npc_name: str, min_priority: int = 5) -> List[Goal]:
        """Get all active goals above a priority threshold"""
        if npc_name not in self.goals:
            return []
            
        active = []
        for category in ['long_term', 'short_term', 'daily']:
            active.extend([
                g for g in self.goals[npc_name][category]
                if not g.completed and not g.abandoned and g.priority >= min_priority
            ])
        
        return sorted(active, key=lambda x: x.priority, reverse=True)
    
    def get_highest_priority_goal(self, npc_name: str) -> Optional[Goal]:
        """Get the NPC's current highest priority goal"""
        active = self.get_active_goals(npc_name)
        return active[0] if active else None
    
    def _record_achievement(self, npc_name: str, goal: Goal, current_day: int):
        """Record a completed goal as an achievement"""
        if not goal.completed or goal in [a.goal for a in self.achievements if a.npc_name == npc_name]:
            return
            
        self.achievements.append(Achievement(
            npc_name=npc_name,
            goal=goal.goal,
            completed_day=current_day,
            impact=goal.completion_reward or "Goal achieved"
        ))
        
        # Remove from active goals
        for category in self.goals[npc_name].values():
            if goal in category:
                category.remove(goal)
                
    def _record_failure(self, npc_name: str, goal: Goal, current_day: int):
        """Record a failed goal"""
        if goal in [f.goal for f in self.failures if f.npc_name == npc_name]:
            return
            
        self.failures.append(Failure(
            npc_name=npc_name,
            goal=goal.goal,
            failed_day=current_day,
            consequence=goal.failure_consequence or "Goal abandoned"
        ))
        
        # Remove from active goals
        for category in self.goals[npc_name].values():
            if goal in category:
                category.remove(goal)
    
    def get_statistics(self) -> Dict:
        """Get system statistics"""
        return {
            'total_npcs_with_goals': len(self.goals),
            'total_active_goals': sum(
                len(cat) for npc_goals in self.goals.values()
                for cat in npc_goals.values()
            ),
            'total_achievements': len(self.achievements),
            'total_failures': len(self.failures)
        }
    
    def export(self) -> Dict:
        """Export goals data for saving"""
        return {
            'goals': {
                name: {
                    category: [vars(g) for g in goals]
                    for category, goals in npc_goals.items()
                }
                for name, npc_goals in self.goals.items()
            },
            'achievements': [vars(a) for a in self.achievements],
            'failures': [vars(f) for f in self.failures]
        }