# systems/needs.py
from typing import TYPE_CHECKING, Dict, List

if TYPE_CHECKING:
    from entities.npc import NPC


class NeedsSystem:
    def __init__(self):
        self.desperation_thresholds = {
            'hunger': 20, 'energy': 15, 'bladder': 85, 'hygiene': 25,
            'fun': 20, 'social': 25, 'horny': 80
        }
        self.critical_thresholds = {
            'hunger': 10, 'energy': 5, 'bladder': 95, 'hygiene': 10,
            'fun': 10, 'social': 10, 'horny': 90
        }

    def process_needs(self, npcs: List['NPC'], hours: float):
        """Called every simulated hour"""
        for npc in npcs:
            if npc.full_name == "Malcolm Newt":
                continue
            npc.needs.update(hours)
            npc.update_state(hours)

    def get_desperate_needs(self, npc: 'NPC') -> List[str]:
        desperate = []
        needs_dict = npc.needs.dict()
        for need, value in needs_dict.items():
            threshold = self.desperation_thresholds.get(need, 20)
            if need in ['bladder', 'horny']:
                if value >= threshold:
                    desperate.append(need)
            else:
                if value <= threshold:
                    desperate.append(need)
        return desperate

    def get_critical_needs(self, npc: 'NPC') -> List[str]:
        critical = []
        needs_dict = npc.needs.dict()
        for need, value in needs_dict.items():
            threshold = self.critical_thresholds.get(need, 10)
            if need in ['bladder', 'horny']:
                if value >= threshold:
                    critical.append(need)
            else:
                if value <= threshold:
                    critical.append(need)
        return critical

    def get_highest_priority_need(self, npc: 'NPC') -> str:
        needs_dict = npc.needs.dict()
        urgency_scores = {}
        for need, value in needs_dict.items():
            urgency_scores[need] = value if need in ['bladder', 'horny'] else 100 - value
        return max(urgency_scores.items(), key=lambda x: x[1])[0]

    def calculate_need_pressure(self, npc: 'NPC') -> float:
        desperate = len(self.get_desperate_needs(npc))
        critical = len(self.get_critical_needs(npc))
        return min(100, (desperate * 10) + (critical * 25))

    def suggest_action(self, npc: 'NPC') -> Dict[str, str]:
        critical = self.get_critical_needs(npc)
        if critical:
            need = critical[0]
            return self._get_action_for_need(need, critical=True)
        desperate = self.get_desperate_needs(npc)
        if desperate:
            need = desperate[0]
            return self._get_action_for_need(need, critical=False)
        return {'action': 'free_time', 'location': npc.current_location}

    def _get_action_for_need(self, need: str, critical: bool = False) -> Dict[str, str]:
        actions = {
            'hunger': {'action': 'eat', 'location': 'Kitchen'},
            'energy': {'action': 'sleep' if critical else 'rest', 'location': 'Bedroom'},
            'bladder': {'action': 'use_bathroom', 'location': 'Bathroom'},
            'hygiene': {'action': 'shower', 'location': 'Bathroom'},
            'fun': {'action': 'entertainment', 'location': 'Living Room'},
            'social': {'action': 'socialize', 'location': 'Public'},
            'horny': {'action': 'private_relief' if critical else 'ignore', 'location': 'Bedroom'}
        }
        return actions.get(need, {'action': 'idle', 'location': 'Home'})