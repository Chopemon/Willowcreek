# systems/autonomous.py
from typing import TYPE_CHECKING
import random

if TYPE_CHECKING:
    from core.simulation_v2 import WillowCreekSimulation
    from entities.npc import NPC


class AutonomousSystem:
    def __init__(self, sim: 'WillowCreekSimulation'):
        self.sim = sim

    def process_all(self, hours: float):
        for npc in self.sim.npcs:
            if npc.full_name == "Malcolm Newt":
                continue

            # 1. Critical needs override everything
            action = self.sim.needs.suggest_action(npc)
            if action['action'] != 'free_time':
                npc.current_location = self._resolve_location(action['location'])
                continue

            # 2. Goals
            goal = self.sim.goals.get_highest_priority_goal(npc.full_name)
            if goal and random.random() < 0.8:
                npc.current_location = self._goal_to_location(goal, npc)
                continue

            # 3. Default schedule
            self._default_schedule(npc)

    def _resolve_location(self, suggested: str) -> str:
        mapping = {
            'Kitchen': 'Home', 'Bedroom': 'Home', 'Bathroom': 'Home',
            'Living Room': 'Home', 'Public': 'Main Street Diner'
        }
        return mapping.get(suggested, 'Home')

    def _goal_to_location(self, goal, npc: 'NPC') -> str:
        g = goal.goal.lower()
        t = self.sim.time
        if any(x in g for x in ["grade", "homework", "study", "school"]):
            return "Willow Creek High School" if not t.is_weekend and 8 <= t.hour < 15 else "Home"
        if "social" in g or "friend" in g:
            return "Willow Creek Park" if t.hour >= 15 else "Main Street Diner"
        if "horny" in g or "relief" in g or "secret" in g:
            return "Bedroom"
        return npc.current_location

    def _default_schedule(self, npc: 'NPC'):
        hour = self.sim.time.hour
        weekend = self.sim.time.is_weekend

        if 5 <= npc.age <= 18:  # Student
            if not weekend and 8 <= hour < 15:
                npc.current_location = "Willow Creek High School"
            elif 15 <= hour < 20:
                npc.current_location = "Willow Creek Park"
            else:
                npc.current_location = "Home"
        else:
            if not weekend and 9 <= hour < 17:
                if "Teacher" in (npc.occupation or ""):
                    npc.current_location = "Willow Creek High School"
                elif any(x in (npc.occupation or "") for x in ["Artist", "Masseuse", "Pastor"]):
                    npc.current_location = "Home"
                else:
                    npc.current_location = "Main Street Diner"
            else:
                npc.current_location = "Home"